document.getElementById("resumeForm").addEventListener("submit", function(event) {
    event.preventDefault();

    const name = document.getElementById("name").value;
    const email = document.getElementById("email").value;
    const phone = document.getElementById("phone").value;
    const summary = document.getElementById("summary").value;
    const education = document.getElementById("education").value;
    const internship = document.getElementById("internship").value;
    const skills = document.getElementById("skills").value.split(",");
    const languages = document.getElementById("languages").value.split(",");
    const hobbies = document.getElementById("hobbies").value.split(",");

    const resume = {
        name,
        email,
        phone,
        summary,
        education,
        internship,
        skills,
        languages,
        hobbies
    };

    // Send data to server for further processing or storage
    generateResume(resume);
});

function generateResume(resume) {
    let resumeContent = `
        <h2>Resume for ${resume.name}</h2>
        <p>Email: ${resume.email}</p>
        <p>Phone: ${resume.phone}</p>
        <h3>Summary:</h3>
        <p>${resume.summary}</p>
        <h3>Education:</h3>
        <p>${resume.education}</p>
        <h3>Internship:</h3>
        <p>${resume.internship}</p>
        <h3>Skills:</h3>
        <ul>
            ${resume.skills.map(skill => `<li>${skill.trim()}</li>`).join("")}
        </ul>
        <h3>Languages:</h3>
        <ul>
            ${resume.languages.map(language => `<li>${language.trim()}</li>`).join("")}
        </ul>
        <h3>Hobbies:</h3>
        <ul>
            ${resume.hobbies.map(hobby => `<li>${hobby.trim()}</li>`).join("")}
        </ul>
    `;

    // Create a new window to display the resume
    const newWindow = window.open("", "_blank");
    newWindow.document.write(resumeContent);
}
