from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/generate_resume', methods=['POST'])
def generate_resume():
    data = request.json
    name = data['name']
    email = data['email']
    phone = data['phone']
    summary = data['summary']
    education = data['education']
    internship = data['internship']
    skills = data['skills']
    languages = data['languages']
    hobbies = data['hobbies']

    resume = {
        'name': name,
        'email': email,
        'phone': phone,
        'summary': summary,
        'education': education,
        'internship': internship,
        'skills': skills,
        'languages': languages,
        'hobbies': hobbies
    }
    return jsonify(resume)

if __name__ == "__main__":
    app.run(debug=True)
